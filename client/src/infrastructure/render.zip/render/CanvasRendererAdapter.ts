import { VisualEntity } from '../../domain/entities/VisualEntity';
import { RoomState, ChestState, BaseEntityState } from '@game/shared';
import { TextureRenderer, EntityRenderer } from './SupportRenderer';

import warriorImgUrl from './../../../assets/hero/warrior-sword-anim.png'; 
import volhvImgUrl from './../../../assets/hero/volhv.png'; 
import lizardAxeImgUrl from './../../../assets/enemy/lizard-axe.png';
import lizardMageImgUrl from './../../../assets/enemy/lizard-mage.png';
import coinImgUrl from './../../../assets/loot/coin.png';
import potionRedImgUrl from './../../../assets/loot/potion_red.png';
import battleAxeImgUrl from './../../../assets/weapon/axe.png';
import ironSwordImgUrl from './../../../assets/weapon/sword.png';
import fireStaffImgUrl from './../../../assets/weapon/fire_staff.png';
import iceStaffImgUrl from './../../../assets/weapon/ice_staff.png';
import chestImgUrl from '../../../assets/chest.png';
import chestOpenImgUrl from '../../../assets/chest-open.png';

interface MapCell {
    state: 'unseen' | 'visible' | 'visited';
    type?: string;
}

export class CanvasRendererAdapter {
    private context: CanvasRenderingContext2D;
    private canvas: HTMLCanvasElement;
    private visitedMatrix: MapCell[][] = [];
    private readonly matrixSize = 10;

    private offscreenCanvas: HTMLCanvasElement;
    private offscreenContext: CanvasRenderingContext2D;
    private currentRoomKey: string = '';

    private playerRenderers: Record<string, EntityRenderer>;
    private enemyRenderers: Record<string, EntityRenderer>;
    private textures: Record<string, HTMLImageElement> = {};

    constructor(canvas: HTMLCanvasElement) {
        this.canvas = canvas;
        const ctx = canvas.getContext('2d');
        if (!ctx) throw new Error('Cannot get 2D context');
        this.context = ctx;

        this.offscreenCanvas = document.createElement('canvas');
        this.offscreenCanvas.width = canvas.width;
        this.offscreenCanvas.height = canvas.height;
        const oCtx = this.offscreenCanvas.getContext('2d');
        if (!oCtx) throw new Error('Cannot get offscreen 2D context');
        this.offscreenContext = oCtx;

        this.context.imageSmoothingEnabled = false;
        this.offscreenContext.imageSmoothingEnabled = false;

        this.initVisitedMatrix();

        this.playerRenderers = {
            'Warrior': new TextureRenderer(warriorImgUrl),
            'Mage': new TextureRenderer(volhvImgUrl)
        };

        this.enemyRenderers = {
            'red_box': new TextureRenderer(lizardAxeImgUrl),
            'orange_box': new TextureRenderer(lizardMageImgUrl)
        };

        this.textures = {
            'chest_wooden_closed': this.preloadImage(chestImgUrl),
            'chest_wooden_opened': this.preloadImage(chestOpenImgUrl),
            'chest_gold_closed': this.preloadImage(chestImgUrl),
            'chest_gold_opened': this.preloadImage(chestOpenImgUrl),
            
            'iron_sword': this.preloadImage(ironSwordImgUrl),
            'battle_axe': this.preloadImage(battleAxeImgUrl),
            'staff': this.preloadImage(fireStaffImgUrl),
            'ice_staff': this.preloadImage(iceStaffImgUrl),
            
            'gold_pile': this.preloadImage(coinImgUrl),
            'potion_red': this.preloadImage(potionRedImgUrl)
        };
    }

    private preloadImage(src: string): HTMLImageElement {
        const img = new Image();
        img.src = src;
        return img;
    }

    public render(
        entitiesMap: Map<string, VisualEntity>, 
        room: RoomState | null, 
        staticObstacles: BaseEntityState[], 
        myId: string
    ): void {
        this.clear();
        
        if (room) {
            const roomKey = `${room.gridX}:${room.gridY}`;
            if (this.currentRoomKey !== roomKey) {
                this.currentRoomKey = roomKey;
                this.prerenderStaticScene(room.type, staticObstacles);
            }
        }

        const players = new Map<string, VisualEntity>();
        const enemies = new Map<string, VisualEntity>();
        const bullets = new Map<string, VisualEntity>();

        entitiesMap.forEach((e, id) => {
            if (e.type === 'player') players.set(id, e);
            else if (e.type === 'enemy') enemies.set(id, e);
            else if (e.type === 'bullet') bullets.set(id, e);
        });

        this.drawScreen(players, enemies, bullets, room);
        
        if (!room) return;
        this.updateVisitedRooms(room);
        this.drawGUI(players, myId);
        this.drawPortal(room)

        this.drawDebugHitboxes(entitiesMap, room, staticObstacles); 
    }

    public reset(): void {
        this.initVisitedMatrix();
        this.currentRoomKey = '';
    }

    private prerenderStaticScene(roomType: string, obstacles: BaseEntityState[]): void {
        this.offscreenContext.clearRect(0, 0, this.offscreenCanvas.width, this.offscreenCanvas.height);

        let floorColor = '#3c2415';
        if (roomType === 'Start') floorColor = '#4a2f1b';
        if (roomType === 'Boss') floorColor = '#3a0d0a';
        if (roomType === 'Treasure') floorColor = '#5c4314';
        if (roomType === 'Shop') floorColor = '#1e2b30';

        this.offscreenContext.fillStyle = floorColor;
        this.offscreenContext.fillRect(0, 0, this.offscreenCanvas.width, this.offscreenCanvas.height);

        this.offscreenContext.fillStyle = 'black';
        for (const obstacle of obstacles) {
            this.offscreenContext.fillRect(
                obstacle.x - obstacle.width / 2, 
                obstacle.y - obstacle.height / 2, 
                obstacle.width, 
                obstacle.height
            );
        }
    }

    private initVisitedMatrix(): void {
        this.visitedMatrix = Array(this.matrixSize).fill(null).map(() =>
            Array(this.matrixSize).fill(null).map(() => ({ state: 'unseen', type: undefined }))
        );
    }

    private updateVisitedRooms(room: RoomState): void {
        const x = room.gridX;
        const y = room.gridY;
        if (x < 0 || x >= this.matrixSize || y < 0 || y >= this.matrixSize) return;

        this.visitedMatrix[y][x] = { state: 'visited', type: room.type };

        if (room.hasDoors.Top && y > 0) {
            if (this.visitedMatrix[y - 1][x].state === 'unseen') this.visitedMatrix[y - 1][x] = { state: 'visible' };
        }
        if (room.hasDoors.Bottom && y < this.matrixSize - 1) {
            if (this.visitedMatrix[y + 1][x].state === 'unseen') this.visitedMatrix[y + 1][x] = { state: 'visible' };
        }
        if (room.hasDoors.Left && x > 0) {
            if (this.visitedMatrix[y][x - 1].state === 'unseen') this.visitedMatrix[y][x - 1] = { state: 'visible' };
        }
        if (room.hasDoors.Right && x < this.matrixSize - 1) {
            if (this.visitedMatrix[y][x + 1].state === 'unseen') this.visitedMatrix[y][x + 1] = { state: 'visible' };
        }
    }

    private clear(): void {
        this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }

    private drawGUI(playersMap: Map<string, VisualEntity>, myId: string) {
        const me = playersMap.get(myId);
        if (!me) return;

        const px = Math.round(me.renderX);
        const py = Math.round(me.renderY);
        const r = me.width ?? 15;

        this.context.save();
        const arrowY = py - r - 5;
        this.context.fillStyle = '#d4af37';
        this.context.fillRect(px - 5, arrowY, 10, 3);
        this.context.fillRect(px - 3, arrowY + 3, 6, 3);
        this.context.fillRect(px - 1, arrowY + 6, 2, 3);
        this.context.restore();

        const guiX = 20, guiY = 20, guiWidth = 210, guiHeight = 64;
        const hp = me.hp ?? 100, maxHp = me.maxHp ?? 100;
        const mana = me.mana ?? 100, maxMana = me.maxMana ?? 100;

        const hpRatio = Math.max(0, Math.min(1, hp / maxHp));
        const manaRatio = Math.max(0, Math.min(1, mana / maxMana));

        this.context.save();
        this.context.fillStyle = '#1c0e07';
        this.context.fillRect(guiX, guiY, guiWidth, guiHeight);
        this.context.strokeStyle = '#b8860b';
        this.context.lineWidth = 3;
        this.context.strokeRect(guiX, guiY, guiWidth, guiHeight);

        const barX = guiX + 10, barY = guiY + 8, barWidth = guiWidth - 20, barHeight = 16;

        this.context.fillStyle = '#380805';
        this.context.fillRect(barX, barY, barWidth, barHeight);
        this.context.fillStyle = '#8a1c14';
        this.context.fillRect(barX, barY, Math.floor(barWidth * hpRatio), barHeight);
        this.context.strokeStyle = '#120904';
        this.context.lineWidth = 2;
        this.context.strokeRect(barX, barY, barWidth, barHeight);

        this.context.fillStyle = '#f3e5ab';
        this.context.font = '8px "Press Start 2P", monospace';
        this.context.fillText(`ЖИЗНЬ: ${Math.floor(hp)}/${maxHp}`, barX + 6, barY + 11);

        const manaY = barY + 22, manaHeight = 12;
        this.context.fillStyle = '#0a232d';
        this.context.fillRect(barX, manaY, barWidth, manaHeight);
        this.context.fillStyle = '#1a5f7a';
        this.context.fillRect(barX, manaY, Math.floor(barWidth * manaRatio), manaHeight);
        this.context.strokeStyle = '#120904';
        this.context.lineWidth = 2;
        this.context.strokeRect(barX, manaY, barWidth, manaHeight);

        this.context.fillStyle = '#8ad5f0';
        this.context.font = '7px "Press Start 2P", monospace';
        this.context.fillText(`БАЙКАЛ: ${Math.floor(mana)}/${maxMana}`, barX + 6, manaY + 9);
        
        const goldEl = document.getElementById('hudGold');
        if (goldEl) {
            goldEl.innerText = `${me.gold}`;
        }

        const weaponEl = document.getElementById('hudWeapon');
        if (weaponEl) {
            const weaponNames: Record<string, string> = {
                'iron_sword': 'МЕЧ-КЛАДЕНЕЦ',
                'battle_axe': 'СЕКИРА ПЕРУНА',
                'staff': 'ПОСОХ ОГНЯ',
                'ice_staff': 'ПОСОХ ХЛАДА'
            };
            weaponEl.innerText = weaponNames[me.activeWeaponVisualId] || me.activeWeaponVisualId.toUpperCase();
        }
    }

    private drawScreen(
        playersMap: Map<string, VisualEntity>,
        enemiesMap: Map<string, VisualEntity>,
        bulletsMap: Map<string, VisualEntity>,
        room: RoomState | null
    ): void {
        if (room && this.currentRoomKey) {
            this.context.drawImage(this.offscreenCanvas, 0, 0);
            this.drawDoors(room);
        } else {
            this.context.fillStyle = 'white';
            this.context.fillRect(0, 0, this.canvas.width, this.canvas.height);
        }

        if (room?.chests) this.drawChests(room.chests);
        if (room?.droppedItems) this.drawDroppedItems(room.droppedItems);
        this.drawBullets(bulletsMap);
        this.drawPlayers(playersMap);
        this.drawEnemies(enemiesMap);
        if (!room) return;
        this.drawMiniMap(room.gridX, room.gridY);
    }

    private drawDoors(room: RoomState): void {
        const doorColor = room.isClear ? '#b8860b' : '#5c120c'; 
        this.context.fillStyle = doorColor;

        const doorWidth = 100;
        const doorThickness = 15;

        if (room.hasDoors.Top) this.context.fillRect(this.canvas.width / 2 - doorWidth / 2, 0, doorWidth, doorThickness);
        if (room.hasDoors.Bottom) this.context.fillRect(this.canvas.width / 2 - doorWidth / 2, this.canvas.height - doorThickness, doorWidth, doorThickness);
        if (room.hasDoors.Left) this.context.fillRect(0, this.canvas.height / 2 - doorWidth / 2, doorThickness, doorWidth);
        if (room.hasDoors.Right) this.context.fillRect(this.canvas.width - doorThickness, this.canvas.height / 2 - doorWidth / 2, doorThickness, doorWidth);
    }

    private drawMiniMap(currentGridX: number, currentGridY: number): void {
        const mapSize = 130, padding = 20;
        const mapX = this.canvas.width - mapSize - padding;
        const mapY = padding;

        this.context.fillStyle = 'rgba(26, 15, 10, 0.95)';
        this.context.fillRect(mapX, mapY, mapSize, mapSize);
        this.context.strokeStyle = 'rgba(184, 134, 11, 0.7)';
        this.context.lineWidth = 3;
        this.context.strokeRect(mapX, mapY, mapSize, mapSize);

        const cellWidth = mapSize / this.matrixSize;
        const cellHeight = mapSize / this.matrixSize;
        const cellPadding = 1.5;

        for (let y = 0; y < this.matrixSize; y++) {
            for (let x = 0; x < this.matrixSize; x++) {
                const cell = this.visitedMatrix[y][x];
                if (cell.state === 'unseen') continue;

                const roomX = mapX + x * cellWidth + cellPadding;
                const roomY = mapY + y * cellHeight + cellPadding;
                const roomW = cellWidth - cellPadding * 2;
                const roomH = cellHeight - cellPadding * 2;

                if (cell.state === 'visited') {
                    let cellColor = '#5c3d24';
                    if (cell.type === 'Start') cellColor = '#2d5a27';
                    if (cell.type === 'Boss') cellColor = '#8a1c14';
                    if (cell.type === 'Treasure') cellColor = '#d4af37';
                    if (cell.type === 'Shop') cellColor = '#1c4966';

                    this.context.fillStyle = cellColor;
                    this.context.fillRect(roomX, roomY, roomW, roomH);

                    if (x === currentGridX && y === currentGridY) {
                        this.context.fillStyle = '#ffffff';
                        const markerSize = roomW / 2;
                        this.context.fillRect(roomX + roomW / 2 - markerSize / 2, roomY + roomH / 2 - markerSize / 2, markerSize, markerSize);
                    }
                } else if (cell.state === 'visible') {
                    this.context.strokeStyle = 'rgba(255, 255, 255, 0.4)';
                    this.context.lineWidth = 1;
                    this.context.strokeRect(roomX, roomY, roomW, roomH);
                }
            }
        }
    }

    private drawBullets(bulletsMap: Map<string, VisualEntity>): void {
        bulletsMap.forEach(bullet => {
            let bulletColor = 'black';
            if (bullet.visualId === 'red_ball') bulletColor = 'red';
            else if (bullet.visualId === 'blue_ball') bulletColor = 'blue';

            this.context.save();
            this.context.beginPath();
            
            const radius = Math.round(bullet.width / 2);
            const bx = Math.round(bullet.renderX);
            const by = Math.round(bullet.renderY);
            
            this.context.arc(bx, by, radius, 0, Math.PI * 2);
            this.context.shadowBlur = 8;
            this.context.shadowColor = bulletColor;
            this.context.fillStyle = bulletColor;
            this.context.fill();
            this.context.restore(); 
        });
    }

    private drawPlayers(playersMap: Map<string, VisualEntity>): void {
        playersMap.forEach(player => {
            const renderer = this.playerRenderers[player.visualId];
            if (renderer) renderer.draw(this.context, player);
            else this.drawFallback(player);
        });
    }

    private drawEnemies(enemiesMap: Map<string, VisualEntity>): void {
        enemiesMap.forEach(enemy => {
            const renderer = this.enemyRenderers[enemy.visualId];
            if (renderer) renderer.draw(this.context, enemy);
            else this.drawFallback(enemy);
        });
    }

    private drawChests(chests: ChestState[]): void {
        if (!chests || chests.length === 0) return;

        for (const chest of chests) {
            const cx = Math.round(chest.x - chest.width / 2);
            const cy = Math.round(chest.y - chest.height / 2);
            const cw = Math.round(chest.width);
            const ch = Math.round(chest.height);
            
            let textureKey = 'chest_wooden_closed';
            
            if (chest.presetId === 'chest_gold_boss') {
                textureKey = chest.isOpened ? 'chest_gold_opened' : 'chest_gold_closed';
            } else {
                textureKey = chest.isOpened ? 'chest_wooden_opened' : 'chest_wooden_closed';
            }

            const texture = this.textures[textureKey];
            if (texture) {
                this.context.drawImage(texture, cx, cy, cw, ch);
            }
        }
    }

    private drawDroppedItems(droppedItems: BaseEntityState[]): void {
        if (!droppedItems || droppedItems.length === 0) return;

        for (const item of droppedItems) {
            const ix = Math.round(item.x - item.width / 2);
            const iy = Math.round(item.y - item.height / 2);
            const iw = Math.round(item.width);
            const ih = Math.round(item.height);
            
            this.context.save();
            this.context.shadowColor = 'rgba(0, 0, 0, 0.3)';
            this.context.shadowBlur = 4;
            this.context.shadowOffsetX = 1;
            this.context.shadowOffsetY = 2;

            const texture = this.textures[item.visualId];

            if (texture) {
                this.context.drawImage(texture, ix, iy, iw, ih);
            } else {
                this.context.fillStyle = '#d4af37';
                this.context.fillRect(ix, iy, iw, ih);
            }
            this.context.restore();
        }
    }

    private drawFallback(entity: VisualEntity): void {
        this.context.fillStyle = '#ff00ff';
        this.context.fillRect(entity.renderX - entity.width / 2, entity.renderY - entity.height / 2, entity.width, entity.height);
    }

    private drawDebugHitboxes(
        entitiesMap: Map<string, VisualEntity>, 
        room: RoomState | null, 
        staticObstacles: BaseEntityState[]
    ): void {
        this.context.save();
        this.context.lineWidth = 1;

        entitiesMap.forEach(entity => {
            if (entity.isDying) return;

            let color = '#00ff00'; 
            if (entity.type === 'enemy') color = '#ff0000'; 
            if (entity.type === 'bullet') color = '#ffff00'; 

            this.context.strokeStyle = color;
            this.context.strokeRect(
                Math.round(entity.renderX - entity.width / 2),
                Math.round(entity.renderY - entity.height / 2),
                entity.width,
                entity.height
            );
        });

        if (staticObstacles) {
            this.context.strokeStyle = '#0000ff';
            staticObstacles.forEach(obs => {
                this.context.strokeRect(
                    Math.round(obs.x - obs.width / 2),
                    Math.round(obs.y - obs.height / 2),
                    obs.width,
                    obs.height
                );
            });
        }

        if (room) {
            if (room.chests) {
                this.context.strokeStyle = '#ff00ff';
                room.chests.forEach(chest => {
                    this.context.strokeRect(
                        Math.round(chest.x - chest.width / 2),
                        Math.round(chest.y - chest.height / 2),
                        chest.width,
                        chest.height
                    );
                });
            }

            if (room.droppedItems) {
                this.context.strokeStyle = '#00ffff';
                room.droppedItems.forEach(item => {
                    this.context.strokeRect(
                        Math.round(item.x - item.width / 2),
                        Math.round(item.y - item.height / 2),
                        item.width,
                        item.height
                    );
                });
            }
        }

        this.context.restore();
    }

    private drawPortal(room: RoomState | null): void {
        if (room?.portal?.isActive) {
            this.context.fillStyle = '#681284';
            this.context.fillRect(
                room.portal.x - room.portal.width / 2,
                room.portal.y - room.portal.height / 2,
                room.portal.width,
                room.portal.height
            );
        }
    }
}